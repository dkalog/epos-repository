#ifndef _U_EXECMEM_H_
#define _U_EXECMEM_H_

void *
u_execmem_alloc(unsigned int size);

#endif /* _U_EXECMEM_H_ */
